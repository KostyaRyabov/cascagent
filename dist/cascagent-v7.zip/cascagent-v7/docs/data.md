# cascagent — Модель данных и форматы

> Статус: **проект v2** (spec принят, код мигрируется).
> Документ детализирует Главы IV–V полной документации проекта
> (модель Task, ID-схема, история вызовов, research findings, enriched
> context) применительно к протоколу v2. Источник истины по формату
> общения с LLM — `docs/protocol.md`; по хранению — §3–4 этого файла.

## 1. Эволюция модели Task

**Версия 1 (отвергнута):** категории + сложные поля.

```python
@dataclass
class Task:
    id: str
    task: str
    category: TaskCategory        # > ! ? ⚛ — отвергнуто
    depth: int
    subtasks: List['Task']
    parent_id: Optional[str]
    acceptance: str               # отвергнуто — избыточно
    blocked_by: List[str]         # отвергнуто — определяется порядком
```

Причины отказа:
- категории усложняли промпт (~800 токенов вместо ~50);
- малая модель путалась в символах `> ! ?`;
- acceptance criteria модель генерировала плохо;
- `blocked_by` выводим из структуры дерева и порядка siblings.

**Версия 2 (актуальная, зафиксирована в protocol §4):**

```python
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional

class TaskStatus(str, Enum):
    PENDING = "pending"       # задача ещё НЕ начала работу — ждёт очереди в
                              # FIFO; над ней работают только CPU-инварианты
                              # декомпозиции (F1–F3, эмбеддинги)
    ENRICHMENT = "enrichment" # работа началась, но LLM-вызова ещё нет: этап
                              # подготовки — выбор агента-исполнителя, подбор
                              # MCP-инструментов, запросы в базы знаний/recall,
                              # формирование контекста (process §1.1)
    RUNNING = "running"       # контекст собран, задача выполняется — активный
                              # LLM-вызов (декомпозиция или исполнение атома)
    DONE = "done"             # задача корректно выполнена
    FAILED = "failed"         # ошибка либо недостаточно данных для выполнения

class Task:
    """Все поля формируются за ОДИН шаг — в __init__ (без __post_init__ и
    вторичной записи id). Не dataclass: ручной конструктор даёт гарантию
    «id создан ровно из того created_at, что зафиксирован в этом же вызове»."""

    def __init__(self, brief: str, description: Optional[str] = None, *,
                 is_atom: bool = False, parent: Optional['Task'] = None,
                 canonical: Optional['Task'] = None):
        self.created_at = datetime.now(timezone.utc)  # обязателен, DateTime, не опционален
        self.id = snowflake_ids.next_id(self.created_at)  # snowflake (§2): кодирован
                                              # created_at; генерируется ЗДЕСЬ ровно один раз
        self.brief = brief                    # название одной строкой (~50 токенов, для RAG)
        self.description = description        # что нужно сделать (для LLM); None у атомов
        self.is_atom = is_atom                # CPU-флаг: не декомпозируется (<atom> / F1/F3,
                                              # process §1.3); атом ⇒ description=None
        self.embedding = embed(brief)         # вектор от embed(brief); один прогон в
                                              # конструкторе (плагин TaskParser, plugins §7.4);
                                              # отдельный embedding(description) НЕ хранится (п.2)
        self.canonical = canonical            # v2+ (roadmap #10): ссылка на задачу-оригинал
                                              # при семантическом дубле; в v1 None
        self.status = TaskStatus.PENDING
        self.result = None                    # что получилось после выполнения
        self.parent = parent                  # прямая ссылка на родителя; в живом дереве
                                              # (project-ключ `tasks`) все ссылки — объекты
        self.depth = 0 if parent is None else parent.depth + 1
                                              # уровень детализации: инкремент от родителя
        self.subtasks: List['Task'] = []      # дети; ПОРЯДОК ИСПОЛНЕНИЯ = порядок в этом
                                              # списке (position == index); отдельного поля
                                              # `order` НЕТ — он лишний
        self.started_at = None                # CPU-диспетчер ставит при PENDING → ENRICHMENT
        self.finished_at = None               # ставится при DONE / FAILED
```

> **Позиция sibling'а.** Порядок исполнения детей определяется индексом в
> `parent.subtasks` (`i = parent.subtasks.index(task)`), мутаций порядка —
> `list.insert/reindex`. В SQL-зеркале (§4.2) индекс материализуется колонкой
> `"order"` при сериализации дерева (пишет её только save-слой TaskParser/CPU-диспетчер),
> чтобы пережить перезагрузку из SQLite; в памяти поля `order` не существует.

> **Реализация:** типизация выше — идеалистическая (прямые ссылки `Task`,
> `datetime`). SQLAlchemy-модель kanban (§4.2) хранит те же сущности в
> сериализуемом виде: `parent_id`/`canonical_id` INTEGER (snowflake id), связи
> через `relationship()` восстанавливают ссылки при загрузке; время —
> TIMESTAMP (UTC ISO-8601 в TEXT-колонках legacy-дампов); `embedding` —
> BLOB float32 little-endian (wire-формат, не отдельная модель).

Почему эта модель оптимальна:
1. **`brief` и `description`** — две формы нужны по разным причинам:
   `brief` (~50 токенов) — индекс RAG/semantic-памяти, дубль-детектор, дерево;
   `description` (~200–400 токенов) — передаётся LLM для работы.
   Атомарная подзадача: `description = None`, `is_atom = True` (протокол
   допускает эквивалентную запись `description == ""` — нормализуется
   парсером к `None`, protocol §3).
2. **`is_atom`, `embedding` и `canonical`** — производные CPU-поля, LLM
   их не задаёт:
   `is_atom` выставляется парсером (`<atom>` в описании / глобальный
   `<atom>`) и стадией фильтрации плагина TaskParser (process §1.3, правила
   F1–F3); `embedding` считается один раз при инициализации задачи из `brief`
   и переиспользуется recall/дубль-детектором (не пересчитывать на каждый
   поиск). **Отдельный `embedding(description)` не хранится**: он нужен был
   бы только для проверки «brief ≈ description ⇒ атом» (F1) — это сравнение
   выполняется на лету внутри TaskParser (стадия 2), результат фиксируется
   флагом `is_atom`, а вектор описания дальше нигде не пригождается;
   `canonical` — поле будущего графа задач (roadmap #10), в v1 остаётся `None`.
3. **Нет категорий** — логика «что делать с задачей» вынесена на CPU-слой;
   модель либо декомпозирует, либо пишет `<atom>`.
4. **Нет `blocked_by`** — зависимости определяются из структуры дерева и
   порядка siblings (индекс в `parent.subtasks`): если A идёт раньше B,
   B зависит от A (FIFO-планирование, cpu-offload A9).
5. **Нет `acceptance`** — критерии приёмки включаются в `description`;
   CPU-диспетчер проверяет покрытие результатом ребёнка (A7/A8).
6. **Нет поля `order`** — позиция sibling'а выводится напрямую из порядка в
   `parent.subtasks` (position == index); отдельный счётчик был бы вторым
   источником истины о порядке и рассинхронизировался бы при insert/remove.
7. **В памяти — прямые ссылки, в БД — id.** В живом дереве `parent`,
   `subtasks` и `canonical` — объекты `Task` (никаких `kanban.get(id)` на
   каждый шаг обхода). Сериализация тривиальна: snowflake id уже хранится в
   самом поле `id` задачи, поэтому SQL-строка (§4.2) выводится из объекта без
   отдельного индекса-словаря; при загрузке из Kanban связи восстанавливаются
   по `parent_id` за один проход, а порядок детей — по колонке `"order"`,
   материализованной из позиции в `subtasks` при сохранении.
8. **Иерархия — не в id.** Snowflake id непрозрачен для дерева (в отличие от
   прежней dot-path схемы): родство держится на ссылках `parent`/`subtasks`
   (+ `parent_id` в SQL), порядок siblings — на позиции в списке `subtasks`,
   глубина — на `depth`. Обход «дерево вниз» = индексация `subtasks`,
   «вверх» = цепочка `parent`; сортировка исполнения — `ORDER BY parent_id,
   "order"` (§4.2).
9. **Все поля — за один шаг (`__init__`).** Конструктор фиксирует
   `created_at`, тут же кодирует из него snowflake `id` (без `__post_init__`
   и двойной записи), считает `embedding(brief)` и вычисляет `depth` из
   переданного `parent`. Экземпляр Task с неполным набором полей
   невозможлен — инварианты модели гарантированы самим фактом создания.

Иерархия задач хранится в памяти проекта под системным ключом **`tasks`**
(project-уровень Memory, plugins §5): словарь `{id: Task}` со
ссылками parent/children — единое живое рабочее дерево между плагином
TaskParser и CPU-диспетчером; в процессе декомпозиции оно уже заполнено, а
TaskParser подставляет новое поддерево детей к соответствующему родителю
(process §1.3, три стадии: парсинг → фильтрация → сохранение). Kanban
(SQLite) — персистентное зеркало того же дерева (resume после краша).

State machine статусов и инварианты — `docs/product.md` §5.

## 2. Идентификация задач — snowflake

ID задачи — **snowflake** (алгоритм генерации уникальных ID, Twitter):
монотонный 64-битный целый, в который закодирован момент создания
(`created_at`). Формируется **в конструкторе Task** (`__init__`: сначала
фиксируется `created_at = datetime.now(timezone.utc)`, затем сразу
`id = snowflake_ids.next_id(created_at)` — один вызов, без `__post_init__`
и вторичной записи; TaskParser, process §1.3), поэтому
id существует с первой секунды жизни задачи и содержит дату внутри — по нему
можно восстановить время создания без отдельного lookup.

Битовая компоновка (как в Twitter Snowflake, знаковый int64):

```
┌──────────────────────────────────────────────────────────┐
│ 0 (1 бит) │ Timestamp (41 бит) │ Machine (10) │ Seq (12) │
└──────────────────────────────────────────────────────────┘
   unused      ms от эпохи проекта   node_id      счётчик в пределах мс
```

- **Timestamp (41 бит)** — миллисекунды с эпохи проекта (запас ~69 лет);
- **Machine ID (10 бит)** — идентификатор ноды/процесса (до 1024), из env/config;
- **Sequence (12 бит)** — счётчик в рамках миллисекунды (до 4096 id/ms).

Эпоха проекта: `EPOCH = 2026-01-01T00:00:00Z` (фиксирована в конфиге,
config §4 `[ids] epoch`; менять нельзя — это часть контракта id).

```python
import threading
from datetime import datetime, timezone

class SnowflakeGenerator:
    """Потокобезопасный генератор snowflake id одного процесса."""
    EPOCH_MS  = 1_767_225_600_000   # 2026-01-01T00:00:00Z, ms
    NODE_BITS = 10                  # до 1024 процессов (node_id из env/config)
    SEQ_BITS  = 12                  # до 4096 id на одну миллисекунду

    def __init__(self, node_id: int):
        assert 0 <= node_id < (1 << self.NODE_BITS)
        self.node_id, self._seq, self._last_ms = node_id, 0, -1
        self._lock = threading.Lock()

    def next_id(self, ts: datetime) -> int:
        ms = int(ts.timestamp() * 1000) - self.EPOCH_MS
        with self._lock:
            if ms == self._last_ms:
                self._seq = (self._seq + 1) & ((1 << self.SEQ_BITS) - 1)
                if self._seq == 0:                 # переполнение счётчика в этой мс
                    while ms == self._last_ms:     # ожидаем следующую миллисекунду
                        ms = int(datetime.now(timezone.utc).timestamp() * 1000) - self.EPOCH_MS
            else:
                self._seq = 0
            self._last_ms = ms
        return (ms << 22) | (self.node_id << 12) | self._seq

# обратное преобразование (для отладки/логирования):
def created_at_from_id(task_id: int) -> datetime:
    ms = (task_id >> 22) + SnowflakeGenerator.EPOCH_MS
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc)
```

Свойства схемы:
- **Монотонность**: id возрастают вместе со временем ⇒ «новые задачи раньше
  старых» проверяется простым сравнением чисел (исторично заменяет прежнюю
  FIFO-сортировку по dot-path);
- **Информативность**: `created_at` восстановим из id (§ выше) — дедупликация
  истории и разбор логов не требуют JOIN с таблицей задач;
- **Коллизии исключены** в пределах узла (sequence + ожидание мс); при запуске
  нескольких процессов CPU-диспетчера каждому выдаётся уникальный `node_id`;
- **Компактность**: int64 — одно целое вместо строкового id, без обращения к
  внешнему сервису генерации (децентрализованно, только локальный lock).

В модели Task это реализуется прямо в `__init__` (см. §1 — без dataclass и
`__post_init__`, один вызов генератора):

```python
class Task:
    def __init__(self, brief: str, ...):
        self.created_at = datetime.now(timezone.utc)   # сначала фиксируем время
        self.id = snowflake_ids.next_id(self.created_at)  # затем кодируем из НЕГО id
        # ... остальные поля — в этом же вызове конструктора
```

Что заменили (dot-path `0`, `0.1`, `0.1.2`): родство теперь только через
`parent`/`subtasks` (+ `parent_id` в SQL), порядок siblings — позиция в списке
`parent.subtasks` (в SQL материализуется колонкой `"order"` при сохранении
дерева), глубина — через `depth = parent.depth + 1`. Инварианты загрузки из БД: у каждой задачи
(кроме корневых) есть существующий `parent_id`; `"order"` уникален внутри
`(parent_id, order)`; `depth` согласован с длиной цепочки parent (проверка —
CPU-валидация, cpu-offload A13).

## 3. Опыт выполненных задач (не история вызовов)

**Решение 2026-10-13: отдельной истории LLM-вызовов НЕТ (history.py удалён).**
Каждый запрос в LLM уже обёрнут в задачу: пользовательский запрос — это
корневая Task (`description` = сырой запрос, `brief` = однострочное название,
`summary` = краткое содержание, создаётся ТОЛЬКО для корня — см. §1);
остальные задачи рождаются декомпозицией как обычно. Промежуточные ответы
модели — производный шум, их логирование в JSONL/debug.log себя не оправдало.

Единственный персистентный артефакт — **результат корректно завершённой
задачи**: при переходе в DONE CPU-диспетчер вызывает `kanban.remember_done(id)`
(Kanban, algorithms.md §3), которое пишет в `semantic_memory` (§4.2) пару
`(ключевой текст, result)` и вектор `embed(ключевой текст)`:

- ключевой текст: `summary` для корневой задачи (brief ~50 токенов слишком
  coarse для целого запроса), `brief` для подзадач;
- фильтрация: только DONE с непустым `result`; FAILED/промежуточные — ничего
  не пишут (данные о статусе и так в таблице `tasks`);
- 1:1 с задачей (`source_task_id`, UNIQUE) — повторный remember обновляет row.

Переиспользование (RAG): перед обогащением новой задачи enricher вызывает
`kanban.recall(query=brief, top_k=3, min_similarity=0.7)` — косинус по
эмбеддингам прошлых результатов; найденные пары идут в
`EnrichedContext.semantic_memories` (§6). GC от разрастания —
`forget_old(days=30, max_keep=1000)` (algorithms.md §3).

Метрики вызовов (токены/длительности) собираются StatisticsCollector в
сессионную статистику на лету (plugins.md §7.4, performance.md §5) — без
per-call журнала на диске. Таблица `llm_calls` (§4.2) остаётся в схеме только
для совместимости со старыми БД; кодом не пишется.

## 4. Хранилища

### 4.1 Почему SQLite

| Альтернатива | Почему отвергнута |
|--------------|-------------------|
| PostgreSQL | Избыточно: отдельный сервер, credentials для локальной системы |
| Redis | In-memory, теряется при рестарте; нет транзакций для графа |
| JSON файлы | Нет атомарности/индексов; плохой concurrent access |
| LevelDB/RocksDB | Нет SQL — сложные запросы по графу громоздки |
| **SQLite** | ✅ один файл, ACID-транзакции, индексы, SQL, встроен в Python (stdlib) |

### 4.2 Схема БД (kanban.db)

```sql
CREATE TABLE tasks (
    id INTEGER PRIMARY KEY,                 -- snowflake (data.md §2): кодирован created_at
    parent_id INTEGER REFERENCES tasks(id), -- NULL у корневых задач
    "order" INTEGER NOT NULL DEFAULT 0,     -- позиция среди siblings (порядок = исполнение)
    depth INTEGER NOT NULL DEFAULT 0,       -- = depth(parent) + 1
    brief TEXT NOT NULL,                    -- название (~50 токенов), для RAG/дерева
    description TEXT,                       -- для LLM; NULL у атомов (is_atom=1)
    is_atom INTEGER NOT NULL DEFAULT 0,     -- 0/1: задача не декомпозируется (CPU-флаг)
    embedding BLOB,                         -- float32 little-endian от embed(brief);
                                            -- считается при инициализации задачи
    status TEXT NOT NULL DEFAULT 'pending', -- pending|enrichment|running|done|failed
                                            -- (pending = работа не начата; enrichment —
                                            -- старт: сбор контекста/ресурсов до LLM-вызова)
    result TEXT,                            -- итог выполнения
    created_at TIMESTAMP NOT NULL,          -- datetime UTC (в Python-модели — datetime, data.md §1);
                                            -- из него кодируется snowflake id (§2)
    started_at TIMESTAMP,                   -- проставляется при PENDING → ENRICHMENT
    finished_at TIMESTAMP,                  -- проставляется при DONE / FAILED
    metadata TEXT                           -- JSON: расширения без миграций
);
CREATE INDEX idx_tasks_parent ON tasks(parent_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_depth  ON tasks(depth);
CREATE UNIQUE INDEX idx_tasks_parent_order ON tasks(parent_id, "order");

CREATE TABLE llm_calls (                    -- SQL-зеркало JSONL (§3.2)
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER REFERENCES tasks(id),
    timestamp TEXT NOT NULL,
    prompt_tokens INTEGER,
    completion_tokens INTEGER,
    duration_ms INTEGER,
    think_enabled INTEGER,                  -- 0/1
    is_atom INTEGER,                        -- 0/1
    duplicates_removed INTEGER DEFAULT 0
);

CREATE TABLE research_cache (
    query_hash TEXT PRIMARY KEY,            -- sha256(normalize(query))
    query TEXT NOT NULL,
    findings TEXT NOT NULL,
    sources TEXT,                           -- JSON: список источников
    confidence REAL,
    created_at TEXT NOT NULL
);

CREATE TABLE semantic_memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_brief TEXT NOT NULL,
    task_result TEXT NOT NULL,
    embedding BLOB NOT NULL,                -- float32 little-endian, dim 384–768
    created_at TEXT NOT NULL
);
CREATE INDEX idx_semantic_created ON semantic_memory(created_at);
```

Конвенции: WAL-режим (`PRAGMA journal_mode=WAL`), `foreign_keys=ON`,
`check_same_thread=False` + внешний lock (single-flight CPU-диспетчера
достаточен); время — TIMESTAMP, хранится как UTC ISO-8601 c timezone
offset, при загрузке конвертируется в `datetime` (Python-модель оперирует
только `datetime`, строки не хранит); boolean — INTEGER 0/1.

### 4.3 Ключевые операции Kanban

```python
class Kanban:
    def __init__(self, db_path: Path):
        self.conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def add_task(self, task: Task) -> int: ...            # INSERT (id — snowflake), возвращает id
    def update_status(self, task_id, status, result=None): ...
    def get_pending_tasks(self, depth: int | None = None) -> list[Task]: ...
    def get_siblings(self, task_id) -> list[Task]: ...     # тот же parent, по ("order", id)
    def get_subtasks(self, task_id) -> list[Task]: ...     # дети, по ("order", id)
    def find_similar(self, embedding: bytes, top_k=3) -> list[Task]: ...

    # v7 (process §1.2): ожидание родителя на детей — без стека вызовов.
    def park(self, task_id, *, await_children: bool) -> None: ...
    #   Родитель (Orchestrator уровня) останавливается, дети уже в очереди.
    #   Реализация: статус остаётся RUNNING + флаг waiting_on_children;
    #   resume при старте переводит RUNNING+flag → PENDING (обычная задача).
    def children_pending(self, task_id) -> bool: ...       # есть ли незавершённые дети
    def maybe_wake_parent(self, task_id, *, escalation=False) -> None: ...
    #   Когда последний ребёнок DONE/FAILED: собрать сводку результатов детей
    #   (Summarizer по триггеру CPU-budget, product §4) → положить её в контекст
    #   родителя → вернуть родителя в очередь (escalation=True → аварийный
    #   режим Orchestrator: тупик нижнего уровня).
```

`find_similar`: SQLite не умеет cosine similarity нативно — эмбеддинги
читаем в numpy и считаем на CPU (cpu-offload P2); sqlite-vss/faiss —
опционально при росте базы (>10k записей).

### 4.4 Резервное копирование

SQLite — один файл. Опция `storage.backup_every_n_ops` (config §4.5):
периодический `sqlite3 conn.backup()` в `./data/backups/kanban-<ts>.db`;
ротация — последние N копий. History/debug.log append-only, бэкап не нужен.

## 5. ResearchFinding

```python
@dataclass
class ResearchFinding:
    query: str                    # что искали (normalized — ключ кэша)
    findings: str                 # что нашли (уже сжатием ≤ budget)
    sources: list[str]            # откуда (URL / путь документа)
    confidence: float             # 0.0–1.0 (оценивает сам ResearchAgent)
    created_at: str

    def to_context_block(self) -> str:
        src = ", ".join(self.sources[:3])
        return f"[Исследование: {self.query}]\n{self.findings}\n(источники: {src})"
```

Кэш: ключ `sha256(normalize(query))` (та же нормализация, что exact-match
кэш решений, cpu-offload P1) → повтор исследования = 0 LLM-вызовов;
hit по похожей формулировке — через semantic recall перед вызовом агента.
ResearchAgent — изолированный вызов с собственным коротким system
промптом (product §4); findings попадают в контекст только через
EnrichedContext, модель-декомposer не знает об источнике.

## 6. EnrichedContext

```python
@dataclass
class EnrichedContext:
    rag_documents: list[str] = []          # из документации (RAG)
    semantic_memories: list[str] = []      # из опыта (recall)
    similar_tasks: list[str] = []          # из Kanban
    research_findings: list[ResearchFinding] = []
    completed_siblings: list[dict] = []    # {"brief":..., "result":...}
    total_tokens: int = 0
    confidence: float = 0.0
    gaps: list[str] = []                   # чего не хватает (сигнал CPU-диспетчеру)

    def to_prompt_block(self, max_tokens: int = 500) -> str: ...
```

Принципы сборки (pure function + CPU-библиотеки, cpu-offload P1–P6):
1. enricher собирает источники, форматирует блоками (`Документация:`,
   `Похожий опыт:`, `Выполненные ранее: ✓`, `Результаты исследований:`);
2. превышение бюджета → Selective Context сжатие (P5), затем — обрезка
   по приоритету: siblings > research > semantic > RAG;
3. `total_tokens` считается до отправки (учёт бюджета ctx, stack §6);
4. **модель не знает**, откуда информация — она видит блок «Контекст».

## 7. Связи между сущностями

```
Task ──1:N──> Task (subtasks/parent_id + "order"; id — snowflake, §2)
 │  ├─ 1:N ──> DecompositionCall (history JSONL + llm_calls)
 │  ├─ N:M ──> ResearchFinding (через research_cache по запросу задачи)
 │  └─ 1:1 ──> semantic_memory (remember(brief,result) после DONE)
EnrichedContext — собирается на лету из Kanban + semantic + RAG + cache
```

Навигация: `get_subtasks / get_task(parent_id) / get_siblings`;
обогащение берёт только `[s for s in siblings if s.status == DONE]`.

## 8. Открытые вопросы

- Файн-тюнинг из history.jsonl (упомянут в Главе V оригинала) — вне
  скоупа v0.x; формат записи специально сохраняет полный prompt/raw ответ.
- Порог перехода `find_similar` с numpy-перебора на faiss/sqlite-vss.
- Схема `metadata` JSON — свободная до появления первых реальных расширений.
