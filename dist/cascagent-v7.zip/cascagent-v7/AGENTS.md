# AGENTS.md — cascagent

Инструкция для AI-разработчиков, работающих над кодовой базой `cascagent`.
Этот файл — источник истины по архитектурным решениям. Прочитай его целиком
перед тем как писать код. Все решения здесь уже приняты — не перепроектируй.

---

## 1. Миссия

`cascagent` — мультиагентная система рекурсивной декомпозиции сложных задач
на атомарные подзадачи. Целевое железо: 4GB VRAM / 16GB RAM.

Принцип номер один: **LLM занимается только семантикой и рассуждениями**.
Всё остальное (маршрутизация, поиск инструментов, валидация, память,
формат, опечатки) — детерминированные CPU-алгоритмы.

Каждый агент работает в изолированной сессии с минимальным контекстом.

## 2. Архитектурные принципы (ОБЯЗАТЕЛЬНЫ)

> Единственный источник истины по формулировкам и обоснованиям —
> `docs/principles.md` §2–§3. Здесь — краткая обязательная выжимка;
> при расхождении истинна `principles.md`.

### 2.1 Изоляция агентов
- Каждый вызов LLM — отдельный HTTP-запрос (не продолжение чата).
- Агент получает только свой task + минимум контекста родителя.
- Утечки контекста невозможны физически.

### 2.2 Минимизация контекста
- Не передавать LLM то, что можно вычислить на CPU.
- Не передавать MCP-схемы инструментов (2000+ токенов каждая).
- Selective Context для сжатия длинных выводов.

### 2.3 Перенос логики на CPU

| Задача | Решение | Модуль |
|--------|---------|--------|
| Выбор инструмента из 1000 | BK-tree (O(log n)) | `bk_tree.py` |
| Опечатки в именах | Левенштейн + фонетика | `bk_tree.fix_typo` |
| Похожие задачи | Эмбеддинги + cosine | `semantic.py` |
| Поиск в документации | RAG (BM25 + vectors) | `rag.py` |
| Обогащение контекста | CPU RAG по embedding(brief), не через LLM (process.md §2) | `enricher.py` |
| Состояние задач | SQLite Kanban | `kanban.py` |
| Дубли подзадач | SequenceMatcher | `plugins/task_parser.py` |
| Разбор формата ответа | отступы → brief/description | `plugins/task_parser.py` |
| Анализ провалов | ReflectAgent | `reflector.py` |

### 2.4 Минимальный формат для LLM
Модель отвечает простым текстом, структура парсится на CPU:
```
read_file /tmp/x.txt        # хорошо
{"tool": "read_file", ...}  # плохо — модель думает о формате
```
System prompt ~480 символов; модель не знает про RAG/память/Kanban (v2).

## 3. Технологический стек

- Backend: **llama.cpp server** (`/v1/chat/completions`, save/restore KV
  через `/slots/N?action=save|restore`, prefix caching, flash attention,
  квантованный KV-кэш `--cache-type-k q8_0`).
- Модель: **Qwen3 4B Q4_K_M** (~3.0 GB), think/no_think через `"think"` параметр.
- Хранение: SQLite (Kanban), JSONL (история LLM-вызовов), `.bin` (KV-кэши).
- Python 3.11+: requests, sqlite3, difflib, numpy, Levenshtein, pyyaml, pytest.
- Лицензия Apache 2.0 (файлы LICENSE, NOTICE в корне).
- Эволюация выбора движка (Ollama → llama.cpp → ExLlamaV2/TabbyAPI),
  сравнение моделей и конфигурации — `docs/stack.md`. Кандидат на ревизию
  (TabbyAPI + Qwen3 8B EXL2 4.0bpw) там же, §7 — решение не принято;
  до принятия код пишется под llama.cpp.

Команда запуска сервера-референс — `docs/stack.md §4.1` (не дублировать;
при смене конфига правится только там).

## 4. Протокол декомпозиции (v2 — ультра-простая архитектура)

> Пересмотр протокола: категории `> ! ?` УДАЛЕНЫ. Полная спецификация —
> `docs/protocol.md`. Системный промпт (~480 символов) зафиксирован в
> `parser.SYSTEM_PROMPT` — менять текст можно только вместе с тестами.

Формат вывода модели — простой текст, блоки «название + описание»,
разделённые пустой строкой:

```
Название задачи            <- первая строка блока = brief подзадачи
Описание что нужно сделать <- остальные строки блока = description

                           <- ПУСТАЯ СТРОКА = разделитель подзадач
```

Атомарность — двухуровневая, ровно `<atom>` (или пустой final_response) —
никаких эвристик: `<atom>` второй строкой блока = атомарная подзадача
(`description = None`, `is_atom = True`); весь ответ = одна строка `<atom>`
→ задача не делится. Исключение (тоже детерминированное, CPU): вырожденный
ответ — одна подзадача, чей brief ≈ задача родителя — трактуется как атом
(§3 п.7).

Пост-обработка ответа декомпозиции — единый CPU-плагин **TaskParser**
(полная спецификация — docs/process.md §1.3), три стадии в одном проходе:
парсинг `Task[]` с `embedding = embed(brief)` при инициализации каждой
задачи; фильтрация/проверка (brief == description ⇒ атом; семантический
дубль родителя ⇒ ребёнок удаляется; не осталось детей ⇒ родитель
становится атомом); сохранение — отфильтрованное поддерево подставляется
к нужному родителю в уже заполненную переменную `tasks` памяти проекта.
LLM при этом остаётся только генерацией текста по формату выше.

Модель НЕ знает про категории, RAG, semantic memory, enrichment — всё это
делает CPU-слой вокруг неё (ContextEnricher, DuplicateDetector, Kanban).

Модель данных: `Task(id, brief, description, is_atom, embedding, status,
result, parent, depth, subtasks, created_at, started_at, finished_at)` —
все поля формируются за один шаг в `__init__` (created_at → snowflake id,
embedding(brief), depth от parent; без dataclass/`__post_init__`; отдельного
поля `order` нет — порядок детей = позиция в `parent.subtasks`);
`parent`/`subtasks` — прямые ссылки на объекты `Task` в живом дереве
(в SQL-зеркале — `parent_id` + колонка `"order"`); время — `datetime` (UTC).
`TaskStatus = pending | enrichment | running | done | failed`, где
**pending — задача ещё не начала работу**; обогащение контекстом и
ресурсами (выбор агента, MCP-инструменты, базы знаний) — отдельный этап
**enrichment** между стартом и первым LLM-вызовом. Полная спецификация —
docs/data.md §1. `TaskCategory` из v1 удалён.

## 5. Передача контекста между уровнями

USER-промпт вызова декомпозиции (см. docs/protocol.md §5):

```
Задача: {task.brief}

Контекст:
{enriched_context}          # RAG + semantic recall + siblings (собран CPU)

Выполненные ранее:
- {completed_siblings} ✓

РАЗБЕЙ НА ПОДЗАДАЧИ:
```

- Модель видит только свой task.brief + обогащённый контекст от enricher'а.
- think/no_think выбирается системой по глубине (политика и механика —
  `docs/stack.md §5`, cpu-offload P7) — модель не управляет этим сама.
- Порядок подзадач в списке = порядок исполнения (зависимости решает система).

## 6. Структура проекта (v2)

```
cascagent/
├── src/cascagent/
│   ├── models.py         # Task(brief,description,status), TaskStatus, snowflake-ID [v2 готово]
│   ├── memory.py         # Memory (flat-KV + glob-подписки), Workspace/Project/Agent [v0.1 готово]
│   ├── stream_parser.py  # ResponseParser: feed/commit/finalize, Segment/Word (v5)   [v0.1 готово]
│   ├── plugins/
│   │   ├── base.py       # Plugin/PrePlugin/RuntimePlugin/PostPlugin                  [v0.1 готово]
│   │   └── task_parser.py# SYSTEM_PROMPT, parse_decomposition, дедуп (вместо parser.py+detector.py)
│   ├── history.py        # History (JSONL + debug.log)                   [Этап 1]
│   ├── client.py         # LlamaCppClient                                [Этап 2]
│   ├── cache_manager.py  # save/restore KV через /slots                  [Этап 2]
│   ├── decomposer.py     # DecomposerSession (stateful сессия)           [Этап 3]
│   ├── enricher.py       # ContextEnricher (RAG + semantic + siblings)   [Этап 4+]
│   ├── executor.py       # TaskExecutor                                  [Этап 4+]
│   ├── reflector.py      # ReflectAgent (анализ провалов)                [Этап 4+]
│   ├── researcher.py     # ResearchAgent (изолированный сбор инфы)       [Этап 4+]
│   ├── kanban.py         # SQLite хранилище                              [Этап 3]
│   ├── cli.py            # argparse: --query --max-depth ...             [Этап 3]
│   ├── bk_tree.py        # BKTree + fix_typo                             [готово]
│   ├── semantic.py       # SemanticMemory.remember/recall                [Этап 4]
│   └── rag.py            # BM25 + vector search                          [Этап 4]
├── tests/                # pytest, по файлу на модуль
├── docs/principles.md    # философия и архитектурные принципы, название, лицензия (источник истины)
├── docs/protocol.md      # СПЕЦИФИКАЦИЯ ПРОТОКОЛА v2 (источник истины)
├── docs/architecture.md  # конспект принятых решений
├── docs/product.md       # продукт: сценарии, функции, системные агенты (draft)
├── docs/cpu-offload.md   # реестр CPU-алгоритмов vs LLM-вызовы
├── docs/stack.md         # стек инференса: движки, модели, think, конфиги (draft)
├── docs/data.md          # модель данных: Task v2, dot-path ID, JSONL, схема SQLite
├── docs/prompts.md       # промпты всех агентов, парсинг вывода, антипаттерны
├── docs/config.md        # зависимости core/extras, config.toml, структура
├── docs/algorithms.md    # эталонные реализации CPU-алгоритмов (BK-tree, fuzzy, memory, RAG)
├── docs/performance.md   # кэш L1–L3, префилл, draft model, PerformanceMetrics
├── docs/process.md       # процесс: ленивая декомпозиция, enrichment, Reflect/Research (Глава IX)
├── docs/examples.md      # референсные сквозные логи + anti-примеры (Глава XII)
├── docs/operations.md    # эксплуатация: железо, установка, мониторинг, troubleshooting (Глава XI)
├── docs/plugins.md       # плагинная архитектура агентов v3: секции Pre/Runtime/Post, иерархия Memory, конфиги (Этап 5+)
├── docs/roadmap.md       # АУДИТ ПРОБЕЛОВ + решения: Python для MVP (порт после), timeout/guard/recovery, MVP-чеклист
├── docs/decisions/       # ADR-001..004 (движок, минимальный промпт, без категорий, ленивая декомпозиция)
├── AGENTS.md             # этот файл
├── pyproject.toml
├── README.md
├── LICENSE / NOTICE
└── .gitignore
```

\* примечание устарело: логика parser/detector перенесена в `plugins/task_parser.py`, модули `parser.py`/`detector.py` удалены (2026-10-12).

Модели максимально простые, вся сложность — в CPU-слое вокруг LLM.

## 7. Этапы реализации (v2)

- **Этап 1 (Фундамент):** ✅ models на протоколе v2; парсинг/дедуп в
  `plugins/task_parser.py`; history.py (+тесты; формат записи — docs/data.md §3) — ⬜. pyproject — готов.
- **Этап 2 (LLM-инфраструктура):** client, cache_manager (отложен: slot API нет)
- **Этап 3 (Ядро):** decomposer (DecomposerSession + execute_with_decomposition),
  kanban, cli
- **Этап 4 (CPU-алгоритмы):** ✅ bk_tree; semantic, rag — ⬜
- **Этап 5 (Обвязка агентов):** enricher, executor, reflector, researcher
  (базовый плагинный слой v3 реализован досрочно: memory.py, stream_parser.py, plugins/)
- **Этап 6 (Интеграция):** оставшиеся тесты, README, docs

Процесс выполнения системы (ленивая декомпозиция, enrichment pipeline,
Research/Reflect, суммаризация) специфицирован в `docs/process.md`;
референсные сквозные логи — `docs/examples.md`; эксплуатация —
`docs/operations.md`. Плагинная архитектура агентов (секции Pre/Runtime/Post,
иерархия памяти Workspace/Project/Agent, конфигурации через TOML — план)
специфицирована в `docs/plugins.md`; базовый слой реализован в v0.1,
расширения (каталог плагинов, TOML, breakpoints) — Этап 5+. Аудит непроектированных областей
(20 пробелов) и принятые по ним решения — `docs/roadmap.md`; перед реализацией
новых компонентов сверяйтесь с его чек-листом продакшн-MVP (§8) и открытыми
вопросами (§9).

Текущий статус: см. раздел 10.

## 8. Принципы разработки

0. **Язык: MVP пишется на Python; после MVP — оптимизация/порт на более
   подходящий язык** (решения и следствия — `docs/roadmap.md` §1). Не
   завязывать CPU-алгоритмы на Python-specific трюки, держать форматы на
   диске language-neutral.
1. Никаких эвристик для определения атомарности: только точный `<atom>`
   или пустой final_response.
2. НЕ обрезать список подзадач — возвращать всё после дубль-фильтрации.
3. Честный парсинг: THINK и FINAL RESPONSE разделяются и логируются оба.
4. Без предварительного прогрева модели.
5. Каждый модуль тестируется независимо; чистые функции где возможно.
6. Коммит после каждого завершённого модуля.
7. Обновлять этот файл при реализации крупных компонентов.

## 9. Что НЕ нужно делать

- Мульти-модельные системы; draft model; warmup; ExLlamaV2; batch processing.
- Эвристики вида «если содержит hello world — это атом».
- Просить LLM делать то, что есть в реестре CPU-алгоритмов (`docs/cpu-offload.md` §2):
  парсить формат, искать дубли, выбирать инструменты, планировать очередь,
  хранить/читать состояние. На GPU остаются ровно 5 видов вызовов (§3 того же файла).

## 10. Статус и конвенции

**Архитектура: v2 (ультра-простая)** — принята, документация зафиксирована:
`docs/protocol.md` (источник истины по формату), AGENTS.md §4–6, architecture.md.

Реализовано (v0.1, 113 тестов): `models.py` (v2), `memory.py`
(Workspace/Project/Agent + Memory flat-KV), `stream_parser.py`
(ResponseParser, Segment/Word v5), `plugins/base.py` +
`plugins/task_parser.py` (поглотил parser.py/detector.py, удалены),
`bk_tree.py`.

Ближайшие шаги (порядок — см. docs/roadmap.md, Фаза 2):
1. `history.py` (JSONL + debug.log) + тесты;
2. `client.py` (стриминг, think-параметр, chunk-iterator контракт);
3. `kanban.py` + оркестратор execute_task поверх Agent.run();
4. `cli.py` (--query, рендер дерева) → e2e на MockLLM;
5. Далее по AGENTS.md §7 (enricher/executor/reflector/researcher).

Конвенции кода:
- `from __future__ import annotations` везде; type hints обязательны.
- Докейстры в каждом модуле со ссылкой на раздел этого файла / docs/protocol.md.
- Тесты: `tests/test_<module>.py`, без сети и без llama.cpp (юнит-тесты
  только чистых функций; интеграционные помечать `@pytest.mark.network`).
- PEP 8, max line 88.
